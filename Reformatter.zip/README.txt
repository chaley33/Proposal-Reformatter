(Assuming you have already unzipped the folder somewhere)
1. Go to the directory that contains the main.py file.
2. Click the folder icon located to the left of the current path
3. Type 'powershell' or 'cmd'
4. (FIRST TIME SETUP ONLY) Type 'py -m pip install python-docx'
5. Type 'py main.py'
6. Drag and drop the document into the shell
7. Press enter
8. :)
